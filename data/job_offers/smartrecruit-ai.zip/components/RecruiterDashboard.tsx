import React, { useState } from 'react';
import { 
  UploadCloud, 
  Target, 
  BarChart3, 
  MessageSquare, 
  ChevronRight, 
  Search, 
  User, 
  ArrowLeft,
  Loader2,
  FileText,
  X,
  Copy
} from './ui/Icons';
import { FileUpload } from './ui/FileUpload';
import { mockParseCV, mockParseJD, mockRAGQuery } from '../services/mockBackend';
import { Candidate, JobDescription, ChatMessage } from '../types';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, RadarChart, PolarGrid, PolarAngleAxis, PolarRadiusAxis, Radar, Legend } from 'recharts';

interface RecruiterDashboardProps {
  onBack: () => void;
}

type Tab = 'upload' | 'results' | 'analytics' | 'rag';

export const RecruiterDashboard: React.FC<RecruiterDashboardProps> = ({ onBack }) => {
  const [activeTab, setActiveTab] = useState<Tab>('upload');
  const [jdFile, setJdFile] = useState<JobDescription | null>(null);
  const [candidates, setCandidates] = useState<Candidate[]>([]);
  const [isProcessing, setIsProcessing] = useState(false);
  const [selectedCandidateId, setSelectedCandidateId] = useState<string | null>(null);
  
  // Comparison State
  const [comparisonIds, setComparisonIds] = useState<string[]>([]);
  const [isComparisonOpen, setIsComparisonOpen] = useState(false);
  
  // RAG State
  const [chatHistory, setChatHistory] = useState<ChatMessage[]>([]);
  const [chatInput, setChatInput] = useState("");
  const [isChatLoading, setIsChatLoading] = useState(false);

  const handleProcess = async () => {
    setIsProcessing(true);
    // Simulate processing time
    setTimeout(() => {
      setIsProcessing(false);
      setActiveTab('results');
    }, 2000);
  };

  const handleFileUploads = async (files: File[], type: 'cv' | 'jd') => {
    if (type === 'jd') {
      const data = await mockParseJD(files[0]);
      setJdFile(data);
    } else {
      setIsProcessing(true);
      const newCandidates = await Promise.all(files.map(f => mockParseCV(f)));
      setCandidates(prev => [...prev, ...newCandidates].sort((a, b) => b.matchScore - a.matchScore));
      setIsProcessing(false);
    }
  };

  const toggleComparisonSelection = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setComparisonIds(prev => 
      prev.includes(id) ? prev.filter(cid => cid !== id) : [...prev, id]
    );
  };

  const handleAskQuestion = async () => {
    if (!chatInput.trim()) return;
    
    const newMessage: ChatMessage = {
      id: Date.now().toString(),
      sender: 'user',
      text: chatInput,
      timestamp: new Date()
    };
    
    setChatHistory(prev => [...prev, newMessage]);
    setChatInput("");
    setIsChatLoading(true);

    // Simulate RAG
    const candidateContext = selectedCandidateId 
      ? candidates.find(c => c.id === selectedCandidateId)?.name || "the candidate" 
      : "the candidates";
      
    const response = await mockRAGQuery(newMessage.text, candidateContext);
    
    const aiMessage: ChatMessage = {
      id: (Date.now() + 1).toString(),
      sender: 'ai',
      text: response,
      timestamp: new Date()
    };
    
    setChatHistory(prev => [...prev, aiMessage]);
    setIsChatLoading(false);
  };

  const selectedCandidate = candidates.find(c => c.id === selectedCandidateId);

  // Render Functions
  const renderSidebar = () => (
    <div className="w-64 bg-white border-r border-slate-200 min-h-screen flex flex-col fixed left-0 top-0 bottom-0 z-10">
      <div className="p-6 border-b border-slate-100 flex items-center">
        <div className="h-8 w-8 bg-recruiter-600 rounded-lg mr-3 flex items-center justify-center text-white font-bold">R</div>
        <span className="font-bold text-slate-800">Recruit OS</span>
      </div>
      
      <nav className="flex-1 p-4 space-y-1">
        <button 
          onClick={() => setActiveTab('upload')}
          className={`w-full flex items-center px-4 py-3 text-sm font-medium rounded-lg transition-colors ${activeTab === 'upload' ? 'bg-recruiter-50 text-recruiter-700' : 'text-slate-600 hover:bg-slate-50'}`}
        >
          <UploadCloud size={18} className="mr-3" />
          Upload Docs
        </button>
        <button 
          onClick={() => setActiveTab('results')}
          disabled={candidates.length === 0}
          className={`w-full flex items-center px-4 py-3 text-sm font-medium rounded-lg transition-colors ${activeTab === 'results' ? 'bg-recruiter-50 text-recruiter-700' : 'text-slate-600 hover:bg-slate-50'} ${candidates.length === 0 ? 'opacity-50 cursor-not-allowed' : ''}`}
        >
          <Target size={18} className="mr-3" />
          Matching Results
          {candidates.length > 0 && <span className="ml-auto bg-recruiter-100 text-recruiter-600 py-0.5 px-2 rounded-full text-xs">{candidates.length}</span>}
        </button>
        <button 
          onClick={() => setActiveTab('analytics')}
          disabled={candidates.length === 0}
          className={`w-full flex items-center px-4 py-3 text-sm font-medium rounded-lg transition-colors ${activeTab === 'analytics' ? 'bg-recruiter-50 text-recruiter-700' : 'text-slate-600 hover:bg-slate-50'} ${candidates.length === 0 ? 'opacity-50 cursor-not-allowed' : ''}`}
        >
          <BarChart3 size={18} className="mr-3" />
          Analytics
        </button>
        <button 
          onClick={() => setActiveTab('rag')}
          disabled={candidates.length === 0}
          className={`w-full flex items-center px-4 py-3 text-sm font-medium rounded-lg transition-colors ${activeTab === 'rag' ? 'bg-recruiter-50 text-recruiter-700' : 'text-slate-600 hover:bg-slate-50'} ${candidates.length === 0 ? 'opacity-50 cursor-not-allowed' : ''}`}
        >
          <MessageSquare size={18} className="mr-3" />
          Ask AI
        </button>
      </nav>

      <div className="p-4 border-t border-slate-100">
        <button onClick={onBack} className="flex items-center text-slate-500 hover:text-slate-800 text-sm font-medium">
          <ArrowLeft size={16} className="mr-2" />
          Switch Role
        </button>
      </div>
    </div>
  );

  const renderComparisonModal = () => {
    if (!isComparisonOpen) return null;
    const comparisonCandidates = candidates.filter(c => comparisonIds.includes(c.id));
    
    return (
      <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4 animate-in fade-in duration-200">
         <div className="bg-white rounded-xl shadow-2xl w-full max-w-[95vw] max-h-[90vh] flex flex-col overflow-hidden">
            {/* Header */}
            <div className="p-4 border-b border-slate-200 flex justify-between items-center bg-slate-50">
               <h3 className="font-bold text-xl text-slate-800 flex items-center">
                 <BarChart3 className="mr-2 text-recruiter-600" /> 
                 Compare Candidates ({comparisonCandidates.length})
               </h3>
               <button onClick={() => setIsComparisonOpen(false)} className="p-2 hover:bg-slate-200 rounded-full text-slate-500 transition-colors">
                 <X size={24} />
               </button>
            </div>
            
            {/* Content */}
            <div className="flex-1 overflow-auto p-6 bg-slate-100">
               <div className="flex gap-6 min-w-max pb-4">
                  {comparisonCandidates.map(c => (
                    <div key={c.id} className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden flex flex-col w-[350px]">
                       {/* Card Header */}
                       <div className="p-6 border-b border-slate-100 text-center bg-white relative">
                          <button 
                            className="absolute top-2 right-2 text-slate-400 hover:text-red-500"
                            onClick={(e) => toggleComparisonSelection(c.id, e)}
                            title="Remove from comparison"
                          >
                             <X size={18} />
                          </button>
                          <div className="w-16 h-16 bg-slate-50 border border-slate-200 rounded-full mx-auto flex items-center justify-center mb-3 shadow-sm text-slate-400">
                             <User size={32} />
                          </div>
                          <h4 className="font-bold text-lg text-slate-900 truncate" title={c.name}>{c.name}</h4>
                          <p className="text-xs text-slate-500 mb-3 truncate" title={c.role}>{c.role}</p>
                          <div className={`inline-flex items-center justify-center px-3 py-1 rounded-full text-white text-sm font-bold shadow-sm ${c.matchScore >= 85 ? 'bg-green-500' : c.matchScore >= 75 ? 'bg-yellow-500' : 'bg-slate-500'}`}>
                             {c.matchScore}% Match
                          </div>
                       </div>

                       {/* Body */}
                       <div className="p-6 space-y-6 flex-1 bg-slate-50/30">
                          {/* Radar */}
                          <div className="h-48 -mx-2">
                             <ResponsiveContainer width="100%" height="100%">
                                <RadarChart cx="50%" cy="50%" outerRadius="70%" data={[
                                  { subject: 'Semantic', A: c.scores.semantic, fullMark: 100 },
                                  { subject: 'Skills', A: c.scores.skills, fullMark: 100 },
                                  { subject: 'Exp', A: c.scores.experience, fullMark: 100 },
                                  { subject: 'Edu', A: c.scores.education, fullMark: 100 },
                                ]}>
                                  <PolarGrid />
                                  <PolarAngleAxis dataKey="subject" tick={{ fontSize: 10, fill: '#64748b' }} />
                                  <Radar name={c.name} dataKey="A" stroke="#2563eb" fill="#3b82f6" fillOpacity={0.3} />
                                </RadarChart>
                             </ResponsiveContainer>
                          </div>

                          {/* Stats */}
                          <div className="grid grid-cols-2 gap-3 text-center">
                             <div className="p-3 bg-white border border-slate-200 rounded-lg">
                                <div className="text-[10px] text-slate-400 uppercase font-bold tracking-wider">Experience</div>
                                <div className="font-bold text-slate-800">{c.experienceYears} Yrs</div>
                             </div>
                             <div className="p-3 bg-white border border-slate-200 rounded-lg">
                                <div className="text-[10px] text-slate-400 uppercase font-bold tracking-wider">Grade</div>
                                <div className={`font-bold ${c.grade.startsWith('A') ? 'text-green-600' : 'text-slate-800'}`}>{c.grade}</div>
                             </div>
                          </div>

                          {/* Skills */}
                          <div>
                             <h5 className="text-xs font-bold text-slate-500 uppercase tracking-wider mb-2 flex items-center">
                                <span className="w-1.5 h-1.5 bg-green-500 rounded-full mr-2"></span>
                                Matched Skills
                             </h5>
                             <div className="flex flex-wrap gap-1.5">
                                {c.matchedSkills.slice(0, 10).map(s => (
                                  <span key={s} className="px-2 py-0.5 bg-green-50 text-green-700 text-[10px] font-medium rounded border border-green-100">{s}</span>
                                ))}
                                {c.matchedSkills.length > 10 && <span className="text-[10px] text-slate-400 self-center">+{c.matchedSkills.length - 10}</span>}
                             </div>
                          </div>

                          <div>
                             <h5 className="text-xs font-bold text-slate-500 uppercase tracking-wider mb-2 flex items-center">
                                <span className="w-1.5 h-1.5 bg-red-500 rounded-full mr-2"></span>
                                Missing Skills
                             </h5>
                             <div className="flex flex-wrap gap-1.5">
                                {c.missingSkills.length > 0 ? c.missingSkills.slice(0, 8).map(s => (
                                  <span key={s} className="px-2 py-0.5 bg-red-50 text-red-700 text-[10px] font-medium rounded border border-red-100">{s}</span>
                                )) : <span className="text-xs text-slate-400 italic">None detected</span>}
                             </div>
                          </div>
                          
                          {/* Strengths Preview */}
                           <div>
                             <h5 className="text-xs font-bold text-slate-500 uppercase tracking-wider mb-2">Key Strength</h5>
                             <p className="text-xs text-slate-600 bg-white p-2 rounded border border-slate-200 line-clamp-2">
                               {c.strengths[0]}
                             </p>
                          </div>
                       </div>
                    </div>
                  ))}
               </div>
            </div>
         </div>
      </div>
    );
  };

  const renderUpload = () => (
    <div className="max-w-4xl mx-auto py-10 px-4">
      <h2 className="text-2xl font-bold text-slate-800 mb-6">Setup Recruitment Pipeline</h2>
      
      <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-8 mb-8">
        <h3 className="text-lg font-semibold text-slate-800 mb-4 flex items-center">
          <span className="bg-recruiter-100 text-recruiter-600 h-6 w-6 rounded-full flex items-center justify-center text-xs mr-2">1</span>
          Target Job Description
        </h3>
        {jdFile ? (
          <div className="bg-recruiter-50 border border-recruiter-200 rounded-lg p-4 flex items-start">
            <div className="bg-white p-2 rounded-md shadow-sm mr-4">
               <FileText className="text-recruiter-500" />
            </div>
            <div>
              <h4 className="font-bold text-recruiter-900">{jdFile.title}</h4>
              <p className="text-sm text-recruiter-700">{jdFile.company}</p>
              <div className="flex flex-wrap gap-2 mt-2">
                {jdFile.requiredSkills.slice(0, 4).map(skill => (
                  <span key={skill} className="text-xs bg-white text-recruiter-600 px-2 py-1 rounded-md border border-recruiter-200">{skill}</span>
                ))}
              </div>
            </div>
            <button onClick={() => setJdFile(null)} className="ml-auto text-slate-400 hover:text-recruiter-600">Change</button>
          </div>
        ) : (
          <FileUpload label="Upload Job Description" onFilesSelected={(f) => handleFileUploads(f, 'jd')} />
        )}
      </div>

      <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-8 mb-8">
        <h3 className="text-lg font-semibold text-slate-800 mb-4 flex items-center">
          <span className="bg-recruiter-100 text-recruiter-600 h-6 w-6 rounded-full flex items-center justify-center text-xs mr-2">2</span>
          Candidate CVs
        </h3>
        <FileUpload 
          label="Upload Candidates (Batch)" 
          multiple={true} 
          onFilesSelected={(f) => handleFileUploads(f, 'cv')} 
        />
        {candidates.length > 0 && (
          <div className="mt-4 p-4 bg-slate-50 rounded-lg border border-slate-200">
             <p className="text-slate-700 font-medium">{candidates.length} CVs staged for processing</p>
          </div>
        )}
      </div>

      <div className="flex justify-end">
        <button 
          onClick={handleProcess}
          disabled={!jdFile || candidates.length === 0 || isProcessing}
          className={`flex items-center px-8 py-3 rounded-lg text-white font-medium shadow-md transition-all ${
            !jdFile || candidates.length === 0 ? 'bg-slate-300 cursor-not-allowed' : 'bg-recruiter-600 hover:bg-recruiter-700'
          }`}
        >
          {isProcessing ? (
            <>
              <Loader2 className="animate-spin mr-2" />
              Processing AI Matching...
            </>
          ) : (
            <>
              Analyze & Match Candidates
              <ChevronRight className="ml-2" />
            </>
          )}
        </button>
      </div>
    </div>
  );

  const renderResults = () => {
    if (selectedCandidateId) {
      // Detail View
      return renderCandidateDetail();
    }
    
    // List View
    return (
      <div className="max-w-6xl mx-auto py-8 px-4">
        <div className="flex justify-between items-end mb-6">
          <div>
            <h2 className="text-2xl font-bold text-slate-800">Matching Results</h2>
            <p className="text-slate-500">For role: <span className="font-semibold text-slate-700">{jdFile?.title}</span></p>
          </div>
          
          <div className="flex items-center space-x-4">
             {/* Compare Button */}
             <button 
               onClick={() => setIsComparisonOpen(true)}
               disabled={comparisonIds.length < 2}
               className={`flex items-center px-4 py-2 rounded-lg font-medium transition-all ${
                 comparisonIds.length >= 2 
                 ? 'bg-recruiter-600 text-white shadow-md hover:bg-recruiter-700' 
                 : 'bg-slate-200 text-slate-400 cursor-not-allowed'
               }`}
             >
               <BarChart3 size={16} className="mr-2" />
               Compare ({comparisonIds.length})
             </button>

             {/* Legend */}
             <div className="hidden md:flex space-x-3 text-sm border-l border-slate-300 pl-4">
                <div className="flex items-center"><span className="w-2.5 h-2.5 rounded-full bg-green-500 mr-2"></span>Excellent</div>
                <div className="flex items-center"><span className="w-2.5 h-2.5 rounded-full bg-yellow-500 mr-2"></span>Good</div>
                <div className="flex items-center"><span className="w-2.5 h-2.5 rounded-full bg-slate-300 mr-2"></span>Fair</div>
             </div>
          </div>
        </div>

        <div className="grid grid-cols-1 gap-4">
          {candidates.map((candidate) => {
            const isExcellent = candidate.matchScore >= 85;
            const isGood = candidate.matchScore >= 75 && candidate.matchScore < 85;
            const borderColor = isExcellent ? 'border-l-4 border-l-green-500' : (isGood ? 'border-l-4 border-l-yellow-400' : 'border-l-4 border-l-slate-300');
            const isSelected = comparisonIds.includes(candidate.id);
            
            return (
              <div 
                key={candidate.id} 
                className={`relative bg-white rounded-lg shadow-sm border ${isSelected ? 'border-recruiter-500 ring-1 ring-recruiter-500' : 'border-slate-200'} p-6 flex flex-col md:flex-row items-center hover:shadow-md transition-all cursor-pointer ${borderColor}`} 
                onClick={() => setSelectedCandidateId(candidate.id)}
              >
                {/* Checkbox for selection */}
                <div className="mr-4 flex items-center" onClick={(e) => e.stopPropagation()}>
                   <input 
                      type="checkbox" 
                      checked={isSelected}
                      onChange={(e) => toggleComparisonSelection(candidate.id, e as unknown as React.MouseEvent)}
                      className="w-5 h-5 rounded border-slate-300 text-recruiter-600 focus:ring-recruiter-500 cursor-pointer"
                   />
                </div>

                <div className="flex-1">
                  <div className="flex items-center mb-1">
                    <h3 className="text-lg font-bold text-slate-900 mr-3">{candidate.name}</h3>
                    <span className={`px-2 py-0.5 rounded text-xs font-bold ${isExcellent ? 'bg-green-100 text-green-700' : (isGood ? 'bg-yellow-100 text-yellow-800' : 'bg-slate-100 text-slate-700')}`}>
                      Grade {candidate.grade}
                    </span>
                  </div>
                  <p className="text-slate-500 text-sm mb-3">{candidate.role} • {candidate.experienceYears} Years Exp.</p>
                  
                  <div className="flex flex-wrap gap-2">
                    {candidate.matchedSkills.slice(0, 5).map(skill => (
                      <span key={skill} className="px-2 py-1 bg-green-50 text-green-700 text-xs rounded border border-green-100 flex items-center">
                        <span className="w-1.5 h-1.5 rounded-full bg-green-500 mr-1"></span>
                        {skill}
                      </span>
                    ))}
                    {candidate.missingSkills.slice(0, 2).map(skill => (
                       <span key={skill} className="px-2 py-1 bg-red-50 text-red-700 text-xs rounded border border-red-100 flex items-center">
                       <span className="w-1.5 h-1.5 rounded-full bg-red-500 mr-1"></span>
                       Missing: {skill}
                     </span>
                    ))}
                  </div>
                </div>

                <div className="flex flex-col items-center md:items-end mt-4 md:mt-0 md:ml-6 min-w-[120px]">
                  <div className="text-3xl font-bold text-slate-800">{candidate.matchScore}%</div>
                  <span className="text-xs text-slate-500 uppercase tracking-wide font-medium">Match Score</span>
                  <button className="mt-3 text-recruiter-600 text-sm font-medium hover:underline flex items-center">
                    View Analysis <ChevronRight size={14} />
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    );
  };

  const renderCandidateDetail = () => {
    if (!selectedCandidate) return null;
    return (
      <div className="max-w-6xl mx-auto py-8 px-4">
        <button onClick={() => setSelectedCandidateId(null)} className="mb-6 flex items-center text-slate-500 hover:text-slate-900">
          <ArrowLeft size={16} className="mr-1" /> Back to List
        </button>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Left Column: Profile */}
          <div className="lg:col-span-1 space-y-6">
            <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6 text-center">
              <div className="w-20 h-20 bg-slate-100 rounded-full mx-auto flex items-center justify-center mb-4">
                <User size={32} className="text-slate-400" />
              </div>
              <h2 className="text-xl font-bold text-slate-900">{selectedCandidate.name}</h2>
              <p className="text-slate-500 text-sm">{selectedCandidate.role}</p>
              
              <div className="mt-6 flex justify-center items-center">
                <div className="relative h-32 w-32 flex items-center justify-center">
                   {/* Simple circular progress visualization using SVG */}
                   <svg className="w-full h-full" viewBox="0 0 36 36">
                      <path
                        className="text-slate-100"
                        d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                        fill="none"
                        stroke="currentColor"
                        strokeWidth="3"
                      />
                      <path
                        className={selectedCandidate.matchScore > 80 ? "text-green-500" : "text-recruiter-500"}
                        strokeDasharray={`${selectedCandidate.matchScore}, 100`}
                        d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                        fill="none"
                        stroke="currentColor"
                        strokeWidth="3"
                        strokeLinecap="round"
                      />
                    </svg>
                    <div className="absolute flex flex-col items-center">
                      <span className="text-2xl font-bold text-slate-800">{selectedCandidate.matchScore}%</span>
                      <span className="text-xs text-slate-500">MATCH</span>
                    </div>
                </div>
              </div>
            </div>

            <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
              <h3 className="font-bold text-slate-800 mb-4">Skill Radar</h3>
              <div className="h-64 w-full">
                 <ResponsiveContainer width="100%" height="100%">
                    <RadarChart cx="50%" cy="50%" outerRadius="80%" data={[
                      { subject: 'Semantic', A: selectedCandidate.scores.semantic, fullMark: 100 },
                      { subject: 'Skills', A: selectedCandidate.scores.skills, fullMark: 100 },
                      { subject: 'Exp', A: selectedCandidate.scores.experience, fullMark: 100 },
                      { subject: 'Edu', A: selectedCandidate.scores.education, fullMark: 100 },
                    ]}>
                      <PolarGrid />
                      <PolarAngleAxis dataKey="subject" tick={{ fill: '#64748b', fontSize: 12 }} />
                      <PolarRadiusAxis angle={30} domain={[0, 100]} tick={false}/>
                      <Radar name={selectedCandidate.name} dataKey="A" stroke="#2563eb" fill="#3b82f6" fillOpacity={0.4} />
                    </RadarChart>
                 </ResponsiveContainer>
              </div>
            </div>
          </div>

          {/* Right Column: Analysis */}
          <div className="lg:col-span-2 space-y-6">
            <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
              <h3 className="font-bold text-slate-800 mb-2 flex items-center"><FileText size={18} className="mr-2 text-recruiter-500"/> AI Summary</h3>
              <p className="text-slate-600 leading-relaxed bg-slate-50 p-4 rounded-lg border border-slate-100">
                {selectedCandidate.summary}
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
                <h3 className="font-bold text-green-700 mb-4 flex items-center">
                  <span className="bg-green-100 p-1 rounded mr-2"><Target size={14}/></span>
                  Strengths
                </h3>
                <ul className="space-y-2">
                  {selectedCandidate.strengths.map((str, i) => (
                    <li key={i} className="flex items-start text-sm text-slate-700">
                      <span className="mr-2 mt-1 text-green-500">•</span>
                      {str}
                    </li>
                  ))}
                </ul>
              </div>

              <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
                <h3 className="font-bold text-amber-600 mb-4 flex items-center">
                  <span className="bg-amber-100 p-1 rounded mr-2"><Target size={14}/></span>
                  Missing / Weaknesses
                </h3>
                <ul className="space-y-2">
                   {selectedCandidate.weaknesses.map((wk, i) => (
                    <li key={i} className="flex items-start text-sm text-slate-700">
                      <span className="mr-2 mt-1 text-amber-500">•</span>
                      {wk}
                    </li>
                  ))}
                </ul>
              </div>
            </div>

             <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
                <h3 className="font-bold text-slate-800 mb-4">Matched Skills</h3>
                <div className="flex flex-wrap gap-2">
                  {selectedCandidate.matchedSkills.map(s => (
                    <span key={s} className="px-3 py-1 bg-green-50 text-green-700 border border-green-200 rounded-full text-sm font-medium">{s}</span>
                  ))}
                </div>
                 <h3 className="font-bold text-slate-800 mt-6 mb-4">Missing Skills</h3>
                <div className="flex flex-wrap gap-2">
                  {selectedCandidate.missingSkills.map(s => (
                    <span key={s} className="px-3 py-1 bg-red-50 text-red-700 border border-red-200 rounded-full text-sm font-medium">{s}</span>
                  ))}
                </div>
             </div>
             
             {/* Quick Chat Context */}
             <div className="bg-blue-50 border border-blue-100 rounded-xl p-4 flex items-center justify-between">
                <div>
                  <h4 className="font-bold text-blue-900">Have questions about {selectedCandidate.name}?</h4>
                  <p className="text-sm text-blue-700">Use the AI assistant to query their CV specifically.</p>
                </div>
                <button 
                  onClick={() => {
                    setActiveTab('rag');
                  }}
                  className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg text-sm font-medium"
                >
                  Ask AI
                </button>
             </div>
          </div>
        </div>
      </div>
    );
  };

  const renderAnalytics = () => {
    // Simple mock data aggregation
    const scoreDistribution = [
      { range: '90-100', count: candidates.filter(c => c.matchScore >= 90).length },
      { range: '80-89', count: candidates.filter(c => c.matchScore >= 80 && c.matchScore < 90).length },
      { range: '70-79', count: candidates.filter(c => c.matchScore >= 70 && c.matchScore < 80).length },
      { range: '<70', count: candidates.filter(c => c.matchScore < 70).length },
    ];

    return (
      <div className="max-w-6xl mx-auto py-8 px-4">
        <h2 className="text-2xl font-bold text-slate-800 mb-6">Pipeline Analytics</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-200">
            <h3 className="font-bold text-slate-700 mb-6">Match Score Distribution</h3>
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={scoreDistribution}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="range" />
                  <YAxis />
                  <Tooltip />
                  <Bar dataKey="count" fill="#3b82f6" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>
          
           <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-200">
            <h3 className="font-bold text-slate-700 mb-6">Pipeline Summary</h3>
            <div className="space-y-4">
               <div className="flex justify-between items-center p-4 bg-slate-50 rounded-lg">
                 <span className="text-slate-600">Total Candidates</span>
                 <span className="text-2xl font-bold text-slate-900">{candidates.length}</span>
               </div>
               <div className="flex justify-between items-center p-4 bg-green-50 rounded-lg">
                 <span className="text-green-700">Avg. Match Score</span>
                 <span className="text-2xl font-bold text-green-700">
                   {candidates.length > 0 
                    ? Math.round(candidates.reduce((acc, c) => acc + c.matchScore, 0) / candidates.length)
                    : 0}%
                 </span>
               </div>
               <div className="flex justify-between items-center p-4 bg-blue-50 rounded-lg">
                 <span className="text-blue-700">Interview Ready (A Grade)</span>
                 <span className="text-2xl font-bold text-blue-700">
                   {candidates.filter(c => c.grade.startsWith('A')).length}
                 </span>
               </div>
            </div>
          </div>
        </div>
      </div>
    );
  };

  const renderRAG = () => (
    <div className="flex flex-col h-[calc(100vh-2rem)] max-w-4xl mx-auto py-4 px-4">
       <div className="flex-none mb-4">
          <h2 className="text-2xl font-bold text-slate-800">Ask AI Assistant</h2>
          <p className="text-slate-500">Query your candidate pool using natural language.</p>
          {selectedCandidateId && (
            <div className="mt-2 text-sm bg-blue-50 text-blue-700 px-3 py-1 rounded inline-block border border-blue-100">
              Context: <strong>{candidates.find(c => c.id === selectedCandidateId)?.name}</strong>
              <button onClick={() => setSelectedCandidateId(null)} className="ml-2 hover:underline opacity-60">Clear Context</button>
            </div>
          )}
       </div>

       <div className="flex-1 bg-white border border-slate-200 rounded-xl shadow-sm flex flex-col overflow-hidden">
          <div className="flex-1 overflow-y-auto p-4 space-y-4 bg-slate-50">
             {chatHistory.length === 0 && (
               <div className="text-center text-slate-400 mt-20">
                 <MessageSquare size={48} className="mx-auto mb-4 opacity-50" />
                 <p>Ask questions like:</p>
                 <ul className="mt-4 space-y-2 text-sm">
                   <li>"Who has the most experience with React?"</li>
                   <li>"Does John Doe have any cloud certifications?"</li>
                   <li>"Compare the top 3 candidates."</li>
                 </ul>
               </div>
             )}
             {chatHistory.map(msg => (
               <div key={msg.id} className={`flex ${msg.sender === 'user' ? 'justify-end' : 'justify-start'}`}>
                  <div className={`max-w-[80%] rounded-2xl p-4 ${msg.sender === 'user' ? 'bg-recruiter-600 text-white rounded-br-none' : 'bg-white border border-slate-200 text-slate-800 rounded-bl-none shadow-sm'}`}>
                    <p className="whitespace-pre-wrap">{msg.text}</p>
                    <div className={`text-xs mt-2 ${msg.sender === 'user' ? 'text-blue-100' : 'text-slate-400'}`}>
                      {msg.timestamp.toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}
                    </div>
                  </div>
               </div>
             ))}
             {isChatLoading && (
               <div className="flex justify-start">
                 <div className="bg-white border border-slate-200 rounded-2xl rounded-bl-none p-4 shadow-sm flex items-center space-x-2">
                    <div className="w-2 h-2 bg-slate-400 rounded-full animate-bounce"></div>
                    <div className="w-2 h-2 bg-slate-400 rounded-full animate-bounce delay-75"></div>
                    <div className="w-2 h-2 bg-slate-400 rounded-full animate-bounce delay-150"></div>
                 </div>
               </div>
             )}
          </div>
          <div className="p-4 bg-white border-t border-slate-200">
            <div className="flex space-x-2">
              <input 
                type="text" 
                value={chatInput}
                onChange={(e) => setChatInput(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleAskQuestion()}
                placeholder="Ask a question about the candidates..."
                className="flex-1 border border-slate-300 rounded-lg px-4 py-2 focus:ring-2 focus:ring-recruiter-500 focus:border-recruiter-500 outline-none"
              />
              <button 
                onClick={handleAskQuestion}
                disabled={!chatInput.trim() || isChatLoading}
                className="bg-recruiter-600 text-white px-4 py-2 rounded-lg font-medium hover:bg-recruiter-700 disabled:opacity-50 disabled:cursor-not-allowed"
              >
                Send
              </button>
            </div>
          </div>
       </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-slate-50 pl-64">
      {renderSidebar()}
      <div className="h-full">
        {activeTab === 'upload' && renderUpload()}
        {activeTab === 'results' && renderResults()}
        {activeTab === 'analytics' && renderAnalytics()}
        {activeTab === 'rag' && renderRAG()}
      </div>
      {renderComparisonModal()}
    </div>
  );
};